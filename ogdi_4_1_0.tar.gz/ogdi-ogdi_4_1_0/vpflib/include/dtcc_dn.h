#ifndef H_DTCC_DN
#define H_DTCC_DN

#ifndef H_MGM_D
#include "mgm_d.h"
#endif

#endif
