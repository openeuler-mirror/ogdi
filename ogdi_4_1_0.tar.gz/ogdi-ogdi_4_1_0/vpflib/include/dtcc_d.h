#ifndef H_DTCC_D

#define H_DTCC_D

#ifndef H_COORD_DEF
#include "coord_d.h"
#endif
#ifndef H_DATUM_DEF
#include "datum_d.h"
#endif
#ifndef H_ELLIPS_DEF
#include "ellips_d.h"
#endif
/*#include "unit_d.h"*/

#endif /*H_DTCC_D*/
