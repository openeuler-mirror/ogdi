#ifndef H_SUNRAST
#define H_SUNRAST

#ifndef H_SUNR_DEF
#include "sunrdef.h"
#endif

#ifndef H_SUNR_FUNC
#include "sunrfunc.h"
#endif

#endif
