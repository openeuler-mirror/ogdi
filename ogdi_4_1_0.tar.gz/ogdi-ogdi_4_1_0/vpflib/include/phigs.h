/*
@Phigs
*/

#ifndef H_PHIGS

#define H_PHIGS


#ifndef H_PHIGS_DEF
#include "phigs_d.h"
#endif

#ifndef H_PHIGS_FUNC
#include "phigs_f.h"
#endif

#endif

