
/*
  This header contain the "database" itself. It's a list of values
  for each available data type available in the skeleton driver.
  */

#ifndef DATAINFO_H
#define DATAINFO_H


#endif

