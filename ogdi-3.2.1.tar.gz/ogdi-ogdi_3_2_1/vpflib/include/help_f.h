

void
#if XVT_CC_PROTO
context_sensitive_help(FILE_SPEC * help_file_spec, char *topic);
#else
context_sensitive_help();
    FILE_SPEC      *help_file_spec;
    char           *topic;
#endif

