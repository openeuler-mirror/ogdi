#ifndef H_VIEW

#define H_VIEW

#ifndef H_VIEW_DEF
#include "viewdef.h"
#endif

#ifndef H_VIEW_FUNC
#include "viewfunc.h"
#endif

#endif /* H_VIEW */

