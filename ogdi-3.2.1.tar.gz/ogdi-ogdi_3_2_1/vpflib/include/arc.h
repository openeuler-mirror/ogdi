#ifndef H_ARC
#define H_ARC

#ifndef H_ARC_DEF
#include "arcdef.h"
#endif

#ifndef H_ARC_FUNC
#include "arcfunc.h"
#endif

#endif
