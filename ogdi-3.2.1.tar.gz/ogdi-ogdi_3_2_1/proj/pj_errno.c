/* For full ANSI compliance of global variable */
#ifndef lint
static const char SCCSID[]="@(#)pj_errno.c	4.2	93/06/12	GIE	REL";
#endif

int pj_errno;

/* end */
